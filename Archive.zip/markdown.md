###markdown_//notes.

####heading: # | ## | ### | #### | ##### | ###### |
***

```javascript
//declare language for syntax highlighting with Git and Markdown Here
var codeDsp = (function() { 
    console.log("Three tildas display code in Markdown!")
    };```
    
|[Surround text with [Brackets]](www.google.com) | [Surround hyperlink with (Parenthesis)](www.google.com)|
|--:|:--|
|*italics_italics_italics* | single asterisk |
|**bold_bold_bold** | double asterisk |
|horizontal rules | hyphen/asterisks/underscores
---